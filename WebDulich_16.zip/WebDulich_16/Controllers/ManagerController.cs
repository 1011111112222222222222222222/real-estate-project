﻿using Microsoft.AspNetCore.Mvc;

namespace WebDulich_16.Controllers
{
    public class ManagerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
       public IActionResult Contact() 
        {
            return View();
        }
    }
}
