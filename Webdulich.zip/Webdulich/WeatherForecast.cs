
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using Webdulich.Model;

namespace Webdulich
{
    public class WeatherForecast
    {
        private readonly HttpClient _httpClient;
        public readonly string _apiUrl = "https://api-intern-test.h2aits.com/News/GetById";


        public DateOnly Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
        public string name { get; set; }    
        public string? Summary { get; set; }

        [HttpGet("{url}")]
       
        public async Task<IEnumerable<WeatherForecast>> GetWeatherForecasts()
        {
            return await _httpClient.GetFromJsonAsync<IEnumerable<WeatherForecast>>("WeatherForecast");
        }
        
        public async Task<List<News>> GetNewsAsync(int? id)
        {
            string requestUrl = _apiUrl;
            if (id.HasValue)
            {
                requestUrl += $"?id={id.Value}";
            }
            var response = await _httpClient.GetAsync(_apiUrl);
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<List<News>>(content);
        }


    }
}
