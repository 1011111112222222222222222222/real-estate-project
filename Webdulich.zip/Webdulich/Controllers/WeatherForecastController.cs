using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;
using Webdulich.Model;

namespace Webdulich.Controllers
{
    [ApiController]
    [Route("[controller]")]
        public class WeatherForecastController : ControllerBase
        {
            private readonly HttpClient _httpClient;
        public readonly string _apiUrl = "https://api-intern-test.h2aits.com/News/GetById";


        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };
        public WeatherForecastController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
       [HttpGet("GetNews")]
    
        public async Task<IEnumerable<News>> GetNews()
        {
            var rng = new Random();
            var tasks = Enumerable.Range(1, 5).Select(async index =>
            {
                var news = await _httpClient.GetFromJsonAsync<News>($"https://api-intern-test.h2aits.com/News/GetById/{index}");
                news.Date = DateTime.Now.AddDays(index);
                news.name = Summaries[rng.Next(Summaries.Length)];
                news.nameSlug = Summaries[rng.Next(Summaries.Length)];
                news.description = Summaries[rng.Next(Summaries.Length)];
                news.detail = Summaries[rng.Next(Summaries.Length)];
                return news;
            });

            var results = await Task.WhenAll(tasks);
            return results.ToList();
        }


        [HttpGet("GetWeatherForecasts")]
        public async Task<IEnumerable<WeatherForecast>> GetWeatherForecasts()
        {
            return await _httpClient.GetFromJsonAsync<IEnumerable<WeatherForecast>>("WeatherForecast");
        }
    }
  
    public class News
    {
        public DateTime Date { get; set; }
  
        public string name { get; set; }
        public string nameSlug { get; set; }
        public string description { get; set; }
        public string detail { get; set; }
    }
}
