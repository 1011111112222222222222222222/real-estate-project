﻿using Microsoft.AspNetCore.Builder;
using Webdulich.Controllers;
using Webdulich.Model;
namespace Webdulich
{
    public class Startup
    {
        

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            services.AddHttpClient<WeatherForecast>(client =>
            {
                client.BaseAddress = new Uri("https://api-intern-test.h2aits.com/swagger/index.html#/News/post_News_Create"); 
            });
        
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("swagger/v1/swaggger.json","WebAPI v1"));

            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=News}/{action=IndexNews}/{id?}");
            });
        }
    }
}
