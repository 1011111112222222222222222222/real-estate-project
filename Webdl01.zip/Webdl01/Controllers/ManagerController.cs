﻿using Microsoft.AspNetCore.Mvc;

namespace Webdl01.Controllers
{
    public class ManagerController : Controller
    {
    
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Home()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Contach()
        {
            return View();
        }
    }
}
