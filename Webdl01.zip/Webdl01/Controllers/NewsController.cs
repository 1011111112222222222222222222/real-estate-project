﻿using Microsoft.AspNetCore.Mvc;
using Webdulich.Model; 
using Webdulich.Controllers;

namespace Webdl01.Controllers
{
    public class NewsController : Controller
    {
        private readonly Apisevice _apiService;
        private readonly string _apiUrl = "https://api-intern-test.h2aits.com/News/GetById";

        public async Task<IActionResult> IndexNews(int ?id)
        {
            List<Webdulich.Model.News> news = await _apiService.GetNewsAsync(id);
            return View(news);
        }
    }
}
