﻿using Microsoft.AspNetCore.Mvc;

namespace Web_dulich.Controllers
{
    public class NewsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
